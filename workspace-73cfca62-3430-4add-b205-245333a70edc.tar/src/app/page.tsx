'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { KPICard } from '@/components/dashboard/kpi-card'
import { SocialMediaCard } from '@/components/dashboard/social-media-card'
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart'
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend
} from 'recharts'
import {
  MousePointer2,
  DollarSign,
  Link2,
  TrendingUp,
  Mail,
  Percent,
  Search,
  BarChart3
} from 'lucide-react'

// Chart color configuration
const CHART_COLORS = {
  organic: 'hsl(142 76% 36%)',
  paid: 'hsl(221 83% 53%)',
  social: 'hsl(280 65% 60%)',
  email: 'hsl(25 95% 53%)',
  referral: 'hsl(45 93% 47%)',
  display: 'hsl(0 84% 60%)',
  bounced: 'hsl(0 84% 60%)',
  notOpen: 'hsl(215 25% 27%)',
  uniqueOpen: 'hsl(142 76% 36%)'
}

// Mock data for charts
const conversionsData = [
  { month: 'Jan', conversions: 1200, target: 1000 },
  { month: 'Feb', conversions: 1400, target: 1100 },
  { month: 'Mar', conversions: 1800, target: 1200 },
  { month: 'Apr', conversions: 1600, target: 1300 },
  { month: 'May', conversions: 2000, target: 1400 },
  { month: 'Jun', conversions: 2400, target: 1500 },
  { month: 'Jul', conversions: 2200, target: 1600 },
  { month: 'Aug', conversions: 2800, target: 1700 },
  { month: 'Sep', conversions: 3200, target: 1800 },
  { month: 'Oct', conversions: 3500, target: 1900 },
  { month: 'Nov', conversions: 3800, target: 2000 },
  { month: 'Dec', conversions: 4200, target: 2100 },
]

const sessionsData = [
  { name: 'Organic', value: 35, fill: CHART_COLORS.organic },
  { name: 'Paid', value: 25, fill: CHART_COLORS.paid },
  { name: 'Social', value: 15, fill: CHART_COLORS.social },
  { name: 'Email', value: 12, fill: CHART_COLORS.email },
  { name: 'Referral', value: 8, fill: CHART_COLORS.referral },
  { name: 'Display', value: 5, fill: CHART_COLORS.display },
]

const emailRecipientsData = [
  { name: 'Bounced', value: 8, fill: CHART_COLORS.bounced },
  { name: 'Not Open', value: 42, fill: CHART_COLORS.notOpen },
  { name: 'Unique Open', value: 50, fill: CHART_COLORS.uniqueOpen },
]

// Sparkline data
const clicksSparkline = [320, 450, 400, 520, 480, 610, 580, 720, 680, 850, 790, 920]
const costSparkline = [1200, 1450, 1380, 1620, 1580, 1850, 1720, 2100, 1950, 2300, 2180, 2500]

export default function DigitalMarketingDashboard() {
  const [selectedCampaign, setSelectedCampaign] = useState('q4-2024')
  const [activeTab, setActiveTab] = useState('ppc')

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-3">
              <BarChart3 className="h-6 w-6 text-primary" />
              <h1 className="text-xl font-bold text-foreground">
                Digital Marketing
              </h1>
            </div>
            <div className="flex items-center gap-4">
              <Select value={selectedCampaign} onValueChange={setSelectedCampaign}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Select campaign" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="q4-2024">Q4 2024 Campaign</SelectItem>
                  <SelectItem value="q3-2024">Q3 2024 Campaign</SelectItem>
                  <SelectItem value="q2-2024">Q2 2024 Campaign</SelectItem>
                  <SelectItem value="q1-2024">Q1 2024 Campaign</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="ppc" className="flex items-center gap-2">
              <MousePointer2 className="h-4 w-4" />
              <span>PPC</span>
            </TabsTrigger>
            <TabsTrigger value="seo" className="flex items-center gap-2">
              <Search className="h-4 w-4" />
              <span>SEO</span>
            </TabsTrigger>
            <TabsTrigger value="email" className="flex items-center gap-2">
              <Mail className="h-4 w-4" />
              <span>Email</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="ppc" className="space-y-8">
            {/* KPI Cards */}
            <section>
              <h2 className="text-lg font-semibold text-foreground mb-4">
                Performance Metrics
              </h2>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
                <KPICard
                  title="Clicks"
                  value={15240}
                  trend={{ value: 18.5, isPositive: true }}
                  sparkline={clicksSparkline}
                  icon={<MousePointer2 className="h-5 w-5 text-muted-foreground" />}
                />
                <KPICard
                  title="Cost"
                  value="$18,450"
                  trend={{ value: 12.3, isPositive: false }}
                  sparkline={costSparkline}
                  icon={<DollarSign className="h-5 w-5 text-muted-foreground" />}
                />
                <KPICard
                  title="Backlinks"
                  value={284}
                  trend={{ value: 8.2, isPositive: true }}
                  icon={<Link2 className="h-5 w-5 text-muted-foreground" />}
                />
                <KPICard
                  title="Google Rank"
                  value="#12"
                  trend={{ value: 3, isPositive: true }}
                  trendIcon={<TrendingUp className="h-3 w-3" />}
                  icon={<Search className="h-5 w-5 text-muted-foreground" />}
                />
                <KPICard
                  title="Email Clicks"
                  value={8452}
                  trend={{ value: 15.7, isPositive: true }}
                  icon={<MousePointer2 className="h-5 w-5 text-muted-foreground" />}
                />
                <KPICard
                  title="Open Rate"
                  value="32.5%"
                  trend={{ value: 4.2, isPositive: true }}
                  icon={<Percent className="h-5 w-5 text-muted-foreground" />}
                />
              </div>
            </section>

            {/* Analytics Section */}
            <section className="grid gap-6 lg:grid-cols-2">
              {/* Conversions Chart */}
              <Card className="col-span-1 lg:col-span-2">
                <CardHeader>
                  <CardTitle>Conversions Overview</CardTitle>
                  <CardDescription>Monthly conversion performance vs target</CardDescription>
                </CardHeader>
                <CardContent>
                  <ChartContainer
                    config={{
                      conversions: {
                        label: 'Conversions',
                        color: CHART_COLORS.paid,
                      },
                      target: {
                        label: 'Target',
                        color: CHART_COLORS.organic,
                      },
                    }}
                    className="h-[300px]"
                  >
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={conversionsData}>
                        <defs>
                          <linearGradient id="colorConversions" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={CHART_COLORS.paid} stopOpacity={0.8}/>
                            <stop offset="95%" stopColor={CHART_COLORS.paid} stopOpacity={0}/>
                          </linearGradient>
                          <linearGradient id="colorTarget" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={CHART_COLORS.organic} stopOpacity={0.6}/>
                            <stop offset="95%" stopColor={CHART_COLORS.organic} stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                        <XAxis
                          dataKey="month"
                          className="text-xs text-muted-foreground"
                          tickLine={false}
                          axisLine={false}
                        />
                        <YAxis
                          className="text-xs text-muted-foreground"
                          tickLine={false}
                          axisLine={false}
                        />
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <Area
                          type="monotone"
                          dataKey="conversions"
                          stroke={CHART_COLORS.paid}
                          fillOpacity={1}
                          fill="url(#colorConversions)"
                          strokeWidth={2}
                        />
                        <Area
                          type="monotone"
                          dataKey="target"
                          stroke={CHART_COLORS.organic}
                          fillOpacity={1}
                          fill="url(#colorTarget)"
                          strokeWidth={2}
                          strokeDasharray="5 5"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                </CardContent>
              </Card>

              {/* Sessions Donut Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Traffic Sources</CardTitle>
                  <CardDescription>Distribution by channel</CardDescription>
                </CardHeader>
                <CardContent>
                  <ChartContainer
                    config={{
                      organic: { label: 'Organic' },
                      paid: { label: 'Paid' },
                      social: { label: 'Social' },
                      email: { label: 'Email' },
                      referral: { label: 'Referral' },
                      display: { label: 'Display' },
                    }}
                    className="h-[300px]"
                  >
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={sessionsData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={100}
                          paddingAngle={2}
                          dataKey="value"
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          labelLine={false}
                          className="text-xs"
                        >
                          {sessionsData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.fill} />
                          ))}
                        </Pie>
                        <ChartTooltip content={<ChartTooltipContent />} />
                      </PieChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                </CardContent>
              </Card>

              {/* Email Recipients Donut Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Email Recipients</CardTitle>
                  <CardDescription>Email engagement breakdown</CardDescription>
                </CardHeader>
                <CardContent>
                  <ChartContainer
                    config={{
                      bounced: { label: 'Bounced' },
                      notOpen: { label: 'Not Open' },
                      uniqueOpen: { label: 'Unique Open' },
                    }}
                    className="h-[300px]"
                  >
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={emailRecipientsData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={100}
                          paddingAngle={2}
                          dataKey="value"
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          labelLine={false}
                          className="text-xs"
                        >
                          {emailRecipientsData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.fill} />
                          ))}
                        </Pie>
                        <ChartTooltip content={<ChartTooltipContent />} />
                      </PieChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                </CardContent>
              </Card>
            </section>

            {/* Social Media Section */}
            <section>
              <h2 className="text-lg font-semibold text-foreground mb-4">
                Social Media Performance
              </h2>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
                <SocialMediaCard platform="instagram" followers={125400} growth={8.5} />
                <SocialMediaCard platform="twitter" followers={89600} growth={12.3} />
                <SocialMediaCard platform="facebook" followers={67800} growth={5.2} />
                <SocialMediaCard platform="youtube" followers={45200} growth={15.8} />
                <SocialMediaCard platform="linkedin" followers={32600} growth={9.7} />
                <SocialMediaCard platform="pinterest" followers={28900} growth={6.4} />
              </div>
            </section>
          </TabsContent>

          <TabsContent value="seo">
            <Card>
              <CardHeader>
                <CardTitle>SEO Performance</CardTitle>
                <CardDescription>Search engine optimization metrics and analytics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-center h-[400px] text-muted-foreground">
                  <p>SEO analytics coming soon...</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="email">
            <Card>
              <CardHeader>
                <CardTitle>Email Marketing</CardTitle>
                <CardDescription>Email campaigns and engagement metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-center h-[400px] text-muted-foreground">
                  <p>Email marketing analytics coming soon...</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
// Trigger rebuild
