'use client'

import { LineChart, Line, ResponsiveContainer, Tooltip } from 'recharts'
import { cn } from '@/lib/utils'

interface SparklineProps {
  data: number[]
  color?: string
  width?: number
  height?: number
  className?: string
}

export function Sparkline({
  data,
  color = 'hsl(221 83% 53%)',
  height = 40,
  className
}: SparklineProps) {
  const chartData = data.map((value, index) => ({
    index,
    value
  }))

  return (
    <ResponsiveContainer width="100%" height={height} className={cn(className)}>
      <LineChart data={chartData}>
        <Tooltip
          content={({ active, payload }) => {
            if (active && payload && payload.length) {
              return (
                <div className="rounded-lg border bg-popover p-2 text-xs shadow-md">
                  <div className="font-medium">{payload[0].value?.toLocaleString()}</div>
                </div>
              )
            }
            return null
          }}
        />
        <Line
          type="monotone"
          dataKey="value"
          stroke={color}
          strokeWidth={2}
          dot={false}
          activeDot={false}
        />
      </LineChart>
    </ResponsiveContainer>
  )
}
