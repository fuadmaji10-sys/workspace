'use client'

import { Card, CardContent } from '@/components/ui/card'
import { cn } from '@/lib/utils'
import {
  Instagram,
  Twitter,
  Facebook,
  Youtube,
  Linkedin,
  Image as ImageIcon,
  TrendingUp
} from 'lucide-react'

interface SocialMediaCardProps {
  platform: 'instagram' | 'twitter' | 'facebook' | 'youtube' | 'linkedin' | 'pinterest'
  followers: number
  growth?: number
  className?: string
}

const platformConfig = {
  instagram: {
    icon: Instagram,
    color: 'text-pink-600',
    bgClass: 'bg-pink-50 dark:bg-pink-950/20',
    name: 'Instagram'
  },
  twitter: {
    icon: Twitter,
    color: 'text-sky-500',
    bgClass: 'bg-sky-50 dark:bg-sky-950/20',
    name: 'Twitter'
  },
  facebook: {
    icon: Facebook,
    color: 'text-blue-600',
    bgClass: 'bg-blue-50 dark:bg-blue-950/20',
    name: 'Facebook'
  },
  youtube: {
    icon: Youtube,
    color: 'text-red-600',
    bgClass: 'bg-red-50 dark:bg-red-950/20',
    name: 'YouTube'
  },
  linkedin: {
    icon: Linkedin,
    color: 'text-blue-700',
    bgClass: 'bg-blue-50 dark:bg-blue-950/20',
    name: 'LinkedIn'
  },
  pinterest: {
    icon: ImageIcon,
    color: 'text-red-700',
    bgClass: 'bg-red-50 dark:bg-red-950/20',
    name: 'Pinterest'
  }
}

export function SocialMediaCard({
  platform,
  followers,
  growth,
  className
}: SocialMediaCardProps) {
  const config = platformConfig[platform]
  const Icon = config.icon

  return (
    <Card className={cn('overflow-hidden hover:shadow-md transition-shadow', className)}>
      <CardContent className="p-6">
        <div className="flex items-center gap-3">
          <div className={cn('p-2.5 rounded-lg', config.bgClass)}>
            <Icon className={cn('h-5 w-5', config.color)} />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-muted-foreground">
              {config.name}
            </p>
            <div className="flex items-baseline gap-2 mt-1">
              <h3 className="text-lg font-bold text-foreground">
                {followers.toLocaleString()}
              </h3>
              {growth !== undefined && (
                <div className="flex items-center gap-1 text-xs font-medium text-emerald-600">
                  <TrendingUp className="h-3 w-3" />
                  <span>+{growth}%</span>
                </div>
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-0.5">
              Followers
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
